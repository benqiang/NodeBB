(function (Controller) {
    'use strict';

    var url    = require('url'),
        db     = require('./nodebb').db,
        logger = require('./logger');

    Controller.getUserInfoBySid = function (req, res, next) {
        
        // 读取cookie的测试
        // logger.log('verbose', 'cookie = ' + JSON.stringify(req.cookies));
        // 内容格式
        // cookie = {"connect.sid":"s:TtqiBqCCWlHG-928lKbXrf9DI5fR-XMd.lVb8WrqKVAXwMBUtTjvaxgkxdVFqqGTyd/SdtGg8EKk",
        // "express.sid":"s:C9OCFTWXact5WxP1edWv3hJd0tM9R1aI.mNUkIw85YV3j6VWkQ4CR2Md5AKZDH5b5vfTht9RT360"}

        // var sidStr = req.cookies['express.sid'];
        // var dotIndex = sidStr.indexOf('.');
        // var express_sid = sidStr.slice(2, dotIndex);

        var express_sid = url.parse(req.url, true).query.sid;
        logger.log('verbose', 'getUserInfoBySid-get-express_id = ' + express_sid);
        
 
        db.sessionStore.get(express_sid, function(err, sessionData) {
           
            if (!err && sessionData && sessionData.passport && sessionData.passport.user) {
                var uid = parseInt(sessionData.passport.user, 10);
                logger.log('verbose', 'getUserInfoBySid-success-userid = ' + uid);
                res.json({ok:true, userid:uid});

            } else if (err) {
                logger.log('verbose', 'getUserInfoBySid-failed = query error');
                res.json({ok:false, errmsg:'query error'});

            } else {
                logger.log('verbose', 'getUserInfoBySid-failed = invalid sid');
                res.json({ok:false, errmsg:'invalid sid'});
                
            }        

        }); 

    };


})(module.exports);