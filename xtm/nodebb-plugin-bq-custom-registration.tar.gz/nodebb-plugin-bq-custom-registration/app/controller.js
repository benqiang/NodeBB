(function (Controller) {
    'use strict';

    var url    = require('url'),
        db     = require('./nodebb').db,
        logger = require('./logger');

    Controller.getUserInfoBySid = function (req, res, next) {

        // 读取cookie的测试
        // logger.log('verbose', 'cookie = ' + JSON.stringify(req.cookies));
        // 内容格式
        // cookie = {"connect.sid":"s:TtqiBqCCWlHG-928lKbXrf9DI5fR-XMd.lVb8WrqKVAXwMBUtTjvaxgkxdVFqqGTyd/SdtGg8EKk",
        // "express.sid":"s:C9OCFTWXact5WxP1edWv3hJd0tM9R1aI.mNUkIw85YV3j6VWkQ4CR2Md5AKZDH5b5vfTht9RT360"}

        // var sidStr = req.cookies['express.sid'];
        // var dotIndex = sidStr.indexOf('.');
        // var express_sid = sidStr.slice(2, dotIndex);

        var express_sid = url.parse(req.url, true).query.sid;
        logger.log('verbose', 'getUserInfoBySid-get-express_id = ' + express_sid);


        db.sessionStore.get(express_sid, function(err, sessionData) {

            if (!err && sessionData && sessionData.passport && sessionData.passport.user) {
                var uid = parseInt(sessionData.passport.user, 10);
                logger.log('verbose', 'getUserInfoBySid-success-userid = ' + uid);
                res.json({ok:true, userid:uid});

            } else if (err) {
                logger.log('verbose', 'getUserInfoBySid-failed = query error');
                res.json({ok:false, errmsg:'query error'});

            } else {
                logger.log('verbose', 'getUserInfoBySid-failed = invalid sid');
                res.json({ok:false, errmsg:'invalid sid'});

            }

        });

    };

	Controller.approvalPreview = function (req, res, next) {
		//res.json({ok:true, data: '测试路由是否正常！'});

		var name = url.parse(req.url, true).query.name;
		logger.log('verbose', 'approvalPreview name = ' + name);

		db.getObject('registration:queue:name:' + name, function (err, userData) {
			if (!err) {
				res.render('approvalpreview', userData);
			}
		});

		//var data = {
		//	"_key" : "registration:queue:name:d1001",
		//	"username" : "d1001",
		//	"email" : "d1001@163.com",
		//	"ip" : "::1",
		//	"hashedPassword" : "$2a$12$1HjGX9KAP7O7RSQ4VqKxIOmsNW24B49eESK60pWx.gERyhZfm/Dt2",
		//	"bq_registration_realname" : "d1001",
		//	"bq_registration_company" : "xxx",
		//	"bq_registration_mobile" : "13722211233",
		//	"bq_registration_wechat" : "wx_d1001",
		//	"bq_reg_has_authenticated" : "auth_ing",
		//	"bq_registration_namecard" : "/uploads/namecard/a25702ccb927b1c153db877bf93d58f5.jpg"
		//};


	}

})(module.exports);