(function (Filter) {
    "use strict";

    var async     = require('async'),
		validator = require('validator'),
        logger    = require('./logger'),
        constants = require('./constants');

    /**
     * Hook to render registration page.
     * < filter:register.build >
     *
     * @ param params {object} It is: {req: req, res: res, templateData: data}
     * @ param callback {function}
     */

    Filter.buildRegister = function (params, callback) {
        logger.log('verbose', 'Reponse hook: filter:register.build');

        var customFields = {
        label: '',
        html: '<div class="panel panel-warning">' +
                '<div class="panel-heading">' +
                    '<h3 class="panel-title">' +
                        '认证信息' +
                    '</h3>' +
                '</div>' +
                '<div class="panel-body">' +

                '<strong>真实姓名</strong><br />' +
                '<div class="input-group">' +
                '<input class="form-control" type="text" placeholder="请输入你的真实姓名" name="bq_registration_realname" id="bq_registration_realname" autocorrect="off" autocapitalize="off" autocomplete="off" />' +
                    '<span class="input-group-addon">' +
                        '<span id="bq_registration_realname_notify"><i class="fa fa-circle-o"></i></span>' +
                    '</span>' +
                '</div><br />'+


                '<strong>工作机构</strong><br />' +
                '<div class="input-group">' +
                '<input class="form-control" type="text" placeholder="请输入你所在的公司或机构名称" name="bq_registration_company" id="bq_registration_company" autocorrect="off" autocapitalize="off" autocomplete="off" />' +
                    '<span class="input-group-addon">' +
                        '<span id="bq_registration_company_notify"><i class="fa fa-circle-o"></i></span>' +
                    '</span>' +
                '</div><br />'+

                '<strong>电话</strong><br />' +
                '<div class="input-group">' +
                '<input class="form-control" type="text" placeholder="请输入你的手机号码" name="bq_registration_mobile" id="bq_registration_mobile" autocorrect="off" autocapitalize="off" autocomplete="off" />' +
                    '<span class="input-group-addon">' +
                        '<span id="bq_registration_mobile_notify"><i class="fa fa-circle-o"></i></span>' +
                    '</span>' +
                '</div><br />'+

                '<strong>微信号</strong><br />' +
                '<div class="input-group">' +
                '<input class="form-control" type="text" placeholder="请输入你的微信号" name="bq_registration_wechat" id="bq_registration_wechat" autocorrect="off" autocapitalize="off" autocomplete="off" />' +
                    '<span class="input-group-addon">' +
                        '<span id="bq_registration_wechat_notify"><i class="fa fa-circle-o"></i></span>' +
                    '</span>' +
                '</div><br />'+

				'<strong>名片</strong><br />' +
				'<div class="input-group">' +
				'<input class="form-control" type="file"  name="file_namecard" id="bq_registration_namecard" />' +
				'<span class="input-group-addon">' +
				'<span id="bq_registration_wechat_notify"><i class="fa fa-circle-o"></i></span>' +
				'</span>' +
				'</div><br />'+

                '<input type="hidden" name="bq_reg_has_authenticated" id="bq_reg_has_authenticated"  value="auth_ing"/>' +

            '</div>'
        };

        if (params.templateData.regFormEntry && Array.isArray(params.templateData.regFormEntry)) {
            params.templateData.regFormEntry.push(customFields);
        } else {
            params.templateData.customFields = customFields;
        }

        callback(null, params);
    }

	//'<strong>机构邮箱</strong><br />' +
	//'<div class="input-group">' +
	//'<input class="form-control" type="text" placeholder="请输入你的公司或机构邮箱" name="bq_registration_company_email" id="bq_registration_company_email" autocorrect="off" autocapitalize="off" autocomplete="off" />' +
	//'<span class="input-group-addon">' +
	//'<span id="bq_registration_company_email_notify"><i class="fa fa-circle-o"></i></span>' +
	//'</span>' +
	//'</div><br />'+

	//else if (!params.req.body['bq_registration_company_email'] || params.req.body['bq_registration_company_email'].length < 2) {
	//	callback({source: 'bq_registration_company_email', message: '请输入你的公司或机构邮箱'}, params);
    //
	//} else if (!validator.isEmail(params.req.body['bq_registration_company_email'])) {
	//	callback({source: 'bq_registration_company_email', message: '请输入有效的公司或机构邮箱'}, params);
    //
	//}

    /**
     *  Hook to check custom fields of registration form.
     * < filter:register.check >
     * {req: req, res: res, userData: userData}
     *
     */
    Filter.checkRegister = function (params, callback) {
        logger.log('verbose', 'Response hook: filter:register.check ');
        if (!params.req.body['bq_registration_realname'] || params.req.body['bq_registration_realname'].length < 2) {
            callback(new Error({source: 'bq_registration_company', message: '请输入你的真实姓名'}), params);

        } else if (!params.req.body['bq_registration_company'] || params.req.body['bq_registration_company'].length < 2) {
            callback({source: 'bq_registration_company', message: '请输入你所在的公司或机构名称'}, params);

        } else if (!params.req.body['bq_registration_mobile'] || params.req.body['bq_registration_mobile'].length < 2) {
			callback({source: 'bq_registration_mobile', message: '请输入你的手机号'}, params);

		} else if (!validator.isMobilePhone(params.req.body['bq_registration_mobile'], 'zh-CN')) {
			callback({source: 'bq_registration_mobile', message: '请输入有效的手机号'}, params);

		} else if (!params.req.body['bq_registration_wechat'] || params.req.body['bq_registration_wechat'].length < 2) {
            callback({source: 'bq_registration_wechat', message: '请输入你的微信号'}, params);

        } else if (!params.req.body['bq_reg_has_authenticated'] || params.req.body['bq_reg_has_authenticated'] != 'auth_ing') {
              callback({source: 'bq_reg_has_authenticated', message: '出错啦！请刷新页面重试！'}, params);

        } else {
            callback(null, params);
        }

    }

    /**
     * Hook to confirm which fields need to be saved to db.
     * < filter:user.custom_fields >
     * {[]}
     *
     */
    Filter.customFields = function (customFieldsArr, callback) {
        logger.log('verbose', 'Response hook: filter:user.custom_fields');
        customFieldsArr.push('bq_registration_realname');
        customFieldsArr.push('bq_registration_company');
        //customFieldsArr.push('bq_registration_company_email');
        customFieldsArr.push('bq_registration_mobile');
        customFieldsArr.push('bq_registration_wechat');
        customFieldsArr.push('bq_reg_has_authenticated');

        callback(null, customFieldsArr);
    }

})(module.exports);