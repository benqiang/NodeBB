(function (Database) {
    'use strict';

    var async        = require('async'),
        objectAssign = require('object-assign'),

        db           = require('./nodebb').db,
        constants    = require('./constants'),
        namespace    = constants.NAMESPACE,
        logger       = require('./logger');


})(module.exports);