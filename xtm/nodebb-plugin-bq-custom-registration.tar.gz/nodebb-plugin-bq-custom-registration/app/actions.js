(function (Action) {
	"use strict";

	var logger    = require('./logger');

	Action.handleLoggedIn = function (params) {
		logger.log('verbose', 'Reponse hook: action:user.loggedIn');
	}


})(module.exports);