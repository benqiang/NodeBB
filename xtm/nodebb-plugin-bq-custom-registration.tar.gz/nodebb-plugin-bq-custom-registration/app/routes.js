(function (Module) {
    'use strict';

    var controller = require('./controller');

    Module.setup = function (params, callback) {
        var router      = params.router,
            middleware  = params.middleware,
            nbControllers = params.controllers,
            apiUri = '/api/xtm';

        router.get(apiUri + '/userinfo', controller.getUserInfoBySid);

		router.get('/admin/manage/xtm/approval/preview', middleware.buildHeader, controller.approvalPreview);

        callback();
    };


})(module.exports);