(function (Module) {
    'use strict';

    var controller = require('./controller');

    Module.setup = function (params, callback) {
        var router      = params.router,
            middleware  = params.middleware,
            nbControllers = params.controllers,
            apiUri = '/api/xtm';

        router.get(apiUri + '/userinfo', controller.getUserInfoBySid);

        callback();
    };


})(module.exports);