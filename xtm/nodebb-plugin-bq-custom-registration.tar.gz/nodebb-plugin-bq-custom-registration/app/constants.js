module.exports = Object.freeze({
    NAMESPACE: 'bq:custom_registration'
});