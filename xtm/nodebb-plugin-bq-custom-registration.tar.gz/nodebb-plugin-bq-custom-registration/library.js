(function (Plugin) {
	"use strict";

	var async	  = require('async'),
		_		  = require('underscore'),
		path      = require('path'),

		nconf 	  = require('./app/nodebb').nconf,
		routes    = require('./app/routes'),
		constants = require('./app/constants'),
		filters   = require('./app/filters'),
		logger    = require('./app/logger'),
		actions   = require('./app/actions');

	function init(done) {
		logger.log('verbose', 'Step1: Do plugin init when <static:app.load>. Do nothing now.');
		done();
	}

	function second(callback) {
		logger.log('verbose', 'Step2: Do plugin init when <static:app.load>. Do nothing now.');
		callback();
	}

	/**
	 * Hook to do init: route etc.
	 * <static:app.load >
	 * {app: app, router: router, middleware: middleware, controllers: controllers}
	 */
	Plugin.hooks = {
		filters: filters,
		statics: {
			load: function (params, callback) {
				async.series([
					init,
					second,
					async.apply(routes.setup, params)
				], function(err, results) {
					if (err) {
						return callback(err);
					}
					logger.log('verbose', 'Plugin is initiated successfully');
                    callback(null);
				});
			}
		}
	};

})(module.exports);

